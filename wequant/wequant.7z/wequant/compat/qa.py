"""Compatibility layer (optional).

This module is intentionally empty in v0.
If you still want to call QUANTAXIS during migration, put wrappers here and
keep the public API in `wequant.wefetch` / `wequant.wesu` stable.
"""
