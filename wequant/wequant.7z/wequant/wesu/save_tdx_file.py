from __future__ import annotations

# File-based save is out of scope for wequant; keep stubs for compatibility.


def QA_SU_save_stock_day(*_args, **_kwargs):
    raise NotImplementedError


def QA_SU_save_future_day(*_args, **_kwargs):
    raise NotImplementedError


def QA_SU_save_etf_day(*_args, **_kwargs):
    raise NotImplementedError
